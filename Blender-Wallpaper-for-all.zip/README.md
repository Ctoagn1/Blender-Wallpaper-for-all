# Blender-Wallpaper-for-all
Dependency-free addon for blender on windows/mac/linux that creates a theme based on your wallpaper!
