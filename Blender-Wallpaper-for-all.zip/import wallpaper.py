import wallpaper
import platform
OS = platform.uname()[0]
print(OS.lower())